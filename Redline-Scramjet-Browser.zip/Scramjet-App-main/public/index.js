"use strict";
const form = document.getElementById("sj-form");
const address = document.getElementById("sj-address");
const searchEngine = document.getElementById("sj-search-engine");
const error = document.getElementById("sj-error");
const errorCode = document.getElementById("sj-error-code");
const homePage = document.getElementById("home-page");
const homeForm = document.getElementById("home-form");
const homeAddress = document.getElementById("home-address");
const tabTitle = document.getElementById("tab-title");
const { ScramjetController } = $scramjetLoadController();
const scramjet = new ScramjetController({
  files: { wasm: "/scram/scramjet.wasm.wasm", all: "/scram/scramjet.all.js", sync: "/scram/scramjet.sync.js" }
});
scramjet.init();
const connection = new BareMux.BareMuxConnection("/baremux/worker.js");
let frame = null;
let visited = [];
let historyIndex = -1;
let isHome = true;

function setHome() {
  isHome = true;
  if (frame) frame.frame.remove();
  frame = null;
  homePage.hidden = false;
  address.value = "";
  homeAddress.value = "";
  tabTitle.textContent = "New Tab";
  document.title = "Redline Browser";
  error.textContent = "";
  errorCode.textContent = "";
}
async function navigate(raw) {
  const input = (raw || "").trim();
  if (!input) return;
  error.textContent = "";
  errorCode.textContent = "";
  let url = search(input, searchEngine.value);
  try { await registerSW(); }
  catch (err) { error.textContent = "Failed to register service worker."; errorCode.textContent = String(err); return; }
  try {
    const wispUrl = (location.protocol === "https:" ? "wss" : "ws") + "://" + location.host + "/wisp/";
    if ((await connection.getTransport()) !== "/libcurl/index.mjs") {
      await connection.setTransport("/libcurl/index.mjs", [{ websocket: wispUrl }]);
    }
    if (historyIndex < visited.length - 1) visited = visited.slice(0, historyIndex + 1);
    if (visited[historyIndex] !== url) { visited.push(url); historyIndex = visited.length - 1; }
    address.value = url;
    homeAddress.value = url;
    tabTitle.textContent = new URL(url).hostname;
    document.title = new URL(url).hostname + " — Redline Browser";
    homePage.hidden = true;
    isHome = false;
    if (frame) frame.frame.remove();
    frame = scramjet.createFrame();
    frame.frame.id = "sj-frame";
    document.body.appendChild(frame.frame);
    frame.go(url);
  } catch (err) {
    error.textContent = "This page could not be opened.";
    errorCode.textContent = String(err);
  }
}
form.addEventListener("submit", e => { e.preventDefault(); navigate(address.value); });
homeForm.addEventListener("submit", e => { e.preventDefault(); navigate(homeAddress.value); });
document.querySelectorAll("[data-url]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.url)));
document.getElementById("home-button").addEventListener("click", setHome);
document.getElementById("reload-button").addEventListener("click", () => {
  if (!isHome && historyIndex >= 0) navigateReload(visited[historyIndex]);
});
async function navigateReload(url) {
  // Reload the current URL without adding a duplicate history entry.
  const oldHistory = visited.slice();
  const oldIndex = historyIndex;
  await navigate(url);
  visited = oldHistory;
  historyIndex = oldIndex;
}
document.getElementById("back-button").addEventListener("click", () => {
  if (historyIndex > 0) { historyIndex--; navigateFromHistory(visited[historyIndex]); }
});
document.getElementById("forward-button").addEventListener("click", () => {
  if (historyIndex < visited.length - 1) { historyIndex++; navigateFromHistory(visited[historyIndex]); }
});
async function navigateFromHistory(url) {
  const oldHistory = visited.slice();
  const oldIndex = historyIndex;
  await navigate(url);
  visited = oldHistory;
  historyIndex = oldIndex;
}
document.getElementById("bookmark-button").addEventListener("click", () => {
  if (isHome || !address.value) return;
  const url = address.value;
  const name = new URL(url).hostname.replace(/^www\./, "");
  let bookmarks = [];
  try { bookmarks = JSON.parse(localStorage.getItem("redline-bookmarks") || "[]"); } catch {}
  if (!bookmarks.some(item => item.url === url)) bookmarks.push({ name, url });
  try { localStorage.setItem("redline-bookmarks", JSON.stringify(bookmarks)); } catch {}
  renderBookmarks();
});
function renderBookmarks() {
  let bookmarks = [];
  try { bookmarks = JSON.parse(localStorage.getItem("redline-bookmarks") || "[]"); } catch {}
  const bar = document.querySelector(".bookmarks-bar");
  bar.querySelectorAll(".saved-bookmark").forEach(el => el.remove());
  bookmarks.slice(0, 5).forEach(item => {
    const button = document.createElement("button");
    button.className = "saved-bookmark";
    button.type = "button";
    button.textContent = "☆ " + item.name;
    button.title = item.url;
    button.addEventListener("click", () => navigate(item.url));
    bar.insertBefore(button, bar.querySelector(".bar-label"));
  });
}
renderBookmarks();
document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "l") {
    event.preventDefault(); address.focus(); address.select();
  }
  if (event.key === "Escape" && document.activeElement === address) address.blur();
});
